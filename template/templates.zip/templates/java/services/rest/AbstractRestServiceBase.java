package {service.namespace}.restservice;
					
/**
 * Base Functions for all Rest Services
 */
public class AbstractRestServiceBase {
	
	protected AbstractRestServiceBase() {
	}
	
}