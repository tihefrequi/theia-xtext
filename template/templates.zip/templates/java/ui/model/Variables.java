package {service.namespace}.ui.model;

public class Variables {
	private UserInfos currentUser;

	public UserInfos getCurrentUser() {
		return currentUser;
	}

	public void setCurrentUser(UserInfos currentUser) {
		this.currentUser = currentUser;
	}
}
