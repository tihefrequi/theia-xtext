package {service.namespace}.utils.spring;

import java.util.Set;

import {service.namespace}.auth.IApplicationUser;

public class SpringBootSimpleUser implements IApplicationUser {

	@Override
	public String getUniqueName() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String getDisplayName() {
		// TODO Auto-generated method stub
		return "Frank Lauks";
	}

	@Override
	public String getFirstName() {
		// TODO Auto-generated method stub
		return "Frank";
	}

	@Override
	public String getLastName() {
		// TODO Auto-generated method stub
		return "Lauks";
	}

	@Override
	public String getMiddleName() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String getHonorificPrefix() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String getHonorificSuffix() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String getProfileUrl() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String getPhotoUrl() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String getUserType() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String getPreferredLanguage() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String getLocale() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String getTimeZone() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean getActive() {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public String getCompany() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String getCompanyRelationship() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String getDepartment() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String getDivision() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String getCostCenter() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String getManager() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String getEmail() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String getPhone() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String getInstantMessageAddress() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String getCountry() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String getPostalCode() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String getRegion() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String getLocality() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String getStreetAddress() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String getCustomAttribute1() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String getCustomAttribute2() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String getCustomAttribute3() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String getCustomAttribute4() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String getCustomAttribute5() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String getCustomAttribute6() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String getCustomAttribute7() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String getCustomAttribute8() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String getCustomAttribute9() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String getCustomAttribute10() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Set<String> getGroupUniqueNames() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Set<String> getRoleUniqueNames() {
		// TODO Auto-generated method stub
		return null;
	}

}
