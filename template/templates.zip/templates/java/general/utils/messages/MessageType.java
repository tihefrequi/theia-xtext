package {service.namespace}.utils.messages;
{customcode.import}

public enum MessageType {
  // Order is important here
  Confirmation, Information, Success, Warning, Error,
  {customcode.start}
}

