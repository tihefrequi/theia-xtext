package {service.namespace}.utils.messages;

import java.util.LinkedList;
{customcode.import}

public class Messages extends LinkedList<Message> {

  /**
   * 
   */
  private static final long serialVersionUID = -9123127185369232230L;

  {customcode.start}

}
