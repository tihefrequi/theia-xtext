package {service.namespace}.utils.images.thumbnails;

public enum SpeedQualityIndicator {

	FAST, BALANCED,QUALITY
}
