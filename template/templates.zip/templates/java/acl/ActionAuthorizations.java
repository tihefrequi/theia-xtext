package {service.namespace}.acl;

import java.util.HashMap;

import {service.namespace}.auth.Principals;

public class ActionAuthorizations extends HashMap<String, Principals> {

}
