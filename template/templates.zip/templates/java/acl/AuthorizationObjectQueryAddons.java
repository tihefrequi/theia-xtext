package {service.namespace}.acl;

import java.util.HashSet;

public class AuthorizationObjectQueryAddons extends HashSet<AuthorizationObjectQueryAddon> {

}
