package {service.namespace}.acl;

import java.util.HashMap;

public class AuthorizationObjectQueryAddon extends HashMap<String, String> {

}
