package {batch.namespace}.base;

import com.sap.scheduler.runtime.mdb.MDBJobImplementation;

@SuppressWarnings("serial")
public abstract class AbstractJob extends MDBJobImplementation {

}
